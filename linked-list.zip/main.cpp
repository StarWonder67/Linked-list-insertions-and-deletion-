/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
struct Node{
    int data;
    Node* next;
};

 Node * headPointer = NULL;
 void InsertatHead(int n){
     
     Node * temp = new Node;
     if(headPointer==NULL){
         temp->data=n;
         headPointer=temp;
         temp->next=NULL;
         
        }
     else{
         temp->data=n;
         
         temp->next=headPointer;
         headPointer=temp;
             
         }
     
 }
 
 void Print(){
    
     Node * temp = new Node;
     temp=headPointer;
     
     while(temp!=NULL){
         cout<<temp->data;
         temp=temp->next;
     }
     
 }
 
 void InseratEnd(int m){
     Node * temp =new Node();
     Node * temp1= headPointer; 
     
     if(headPointer==NULL){
         temp->data=m;
         headPointer=temp;
         temp->next=NULL;
         
        }
        else{
         while(temp1->next!=NULL)
         {
             temp1=temp1->next;
         }
         temp->data=m;
         temp1->next=temp;
         temp->next==NULL;
        }
 }
 
void InsertAt(int x,int n){
    Node * temp = new Node;
    Node * temp1=headPointer;
    if(headPointer==NULL){
        temp->data=x;
        temp->next=NULL;
        headPointer=temp;
    }
    else{
        for(int i=0;i<n-2;i++){
            temp1=temp1->next;
        }
        temp->data=x;
        temp->next=temp1->next;
        temp1->next=temp;
    }
}
void deleteNode(int n){
    Node * temp1=headPointer;
    Node * temp2=headPointer;
    if(n==1){
        headPointer==NULL;
        
    }
    else{
        for(int i=0;i<n-2;i++){
            temp1=temp1->next;
        }
        for(int i=0;i<n-1;i++){
            temp2=temp2->next;
        }
        temp1->next=temp2->next;
        delete temp2;
    }
}
 
int main()
{   int i;
   for(i=1;i<5;i++){
       InseratEnd(i);
   }
    Print();
    cout<<endl;
    InsertAt(6,2);
    InsertAt(7,3);
    Print();
    deleteNode(3);
    cout<<endl;
    Print();
    return 0;
}

